# VE-Log GmbH – GitHub Pages Veröffentlichung

Dieses Paket ist auf das vorhandene Repository **VE-Log-GmbH** eingestellt.

## Dateien ins Repository hochladen

1. Lade dieses ZIP herunter und entpacke es.
2. Öffne https://github.com/gunasegaram/VE-Log-GmbH
3. Lade den **gesamten Inhalt dieses Projektordners** in die oberste Ebene des Repositorys hoch. Wichtig: `package.json`, `vite.config.ts`, `index.html`, `src/` und der versteckte Ordner `.github/workflows/` müssen im Repository vorhanden sein. Nicht einen zusätzlichen übergeordneten Ordner namens `VE-Log-GmbH` innerhalb des Repositorys anlegen.
4. Committe die Dateien auf Branch `main`.
5. Öffne **Settings → Pages** und wähle unter **Build and deployment → Source** die Option **GitHub Actions**.
6. Öffne **Actions** und warte, bis „Deploy VE-Log GmbH to GitHub Pages“ erfolgreich abgeschlossen ist.
7. Die Website sollte dann unter https://gunasegaram.github.io/VE-Log-GmbH/ erreichbar sein.

## Falls du über die GitHub-Webseite hochlädst
GitHub-Webupload unterstützt versteckte Ordner nicht immer komfortabel. Achte besonders darauf, dass `.github/workflows/deploy.yml` mit hochgeladen wird. Wenn du diesen Ordner nicht hochladen kannst, verwende GitHub Desktop oder lade die Dateien mit Git hoch.

## Hinweise
- Die bestehende Repository-Adresse `velog` wird durch diese Veröffentlichung nicht ersetzt.
- Die Excel-Kalkulation ist ein Ausgangspunkt. Bitte Ergebnisse mit deiner Original-Excel prüfen, bevor du sie für echte Abrechnungen verwendest.
- Keine vertraulichen Baustellen- oder Kundendaten in ein öffentliches Repository laden.
