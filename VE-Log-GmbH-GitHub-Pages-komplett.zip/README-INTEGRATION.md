# VE-Log GmbH – integrierte Excel-Kalkulation

Die bestehende React/Vite-Anwendung wurde um den Menüpunkt **Excel-Kalkulation** ergänzt.

## Änderungen
- `src/components/ExcelWorkbookPage.tsx`: neue Ansicht zum lokalen Öffnen von Excel-Dateien, Auswählen von Tabellenblättern, Bearbeiten von Zellen und Exportieren als Excel.
- `src/components/Sidebar.tsx`: neuer Menüpunkt „Excel-Kalkulation“.
- `src/App.tsx`: Ansicht in die bestehende Anwendung eingebunden.

## Lokal starten
Voraussetzung: Node.js oder Bun installiert.
1. `npm install` (oder `bun install`)
2. `npm run dev`
3. Die angezeigte lokale URL im Browser öffnen.

## Build
`npm run build`

## Hinweise
- Die Excel-Datei wird im Browser verarbeitet und nicht an einen Server übertragen.
- Der Viewer erhält bestehende Formeln beim Import/Export soweit die SheetJS-Bibliothek dies unterstützt. Formeln werden in der neuen Ansicht nicht wie in Excel neu berechnet. Vor produktivem Einsatz bitte Ergebnisse mit der Originaldatei prüfen.
- Dieses ZIP enthält den Projektquellcode, aber keinen `.git`-Ordner und keine installierten Abhängigkeiten.
- Die `package.json` und vorhandenen Projektdateien wurden beibehalten.
