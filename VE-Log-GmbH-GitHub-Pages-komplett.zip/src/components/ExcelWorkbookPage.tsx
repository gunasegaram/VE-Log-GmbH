import React, { useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { FileSpreadsheet, Upload, Download, Info, ArrowLeft, Check } from 'lucide-react';

type CellSelection = { sheet: string; row: number; col: number };

export const ExcelWorkbookPage: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [book, setBook] = useState<XLSX.WorkBook | null>(null);
  const [fileName, setFileName] = useState('');
  const [sheetName, setSheetName] = useState('');
  const [selected, setSelected] = useState<CellSelection | null>(null);
  const [editValue, setEditValue] = useState('');
  const [message, setMessage] = useState('Lade deine Baustellen-Excel-Datei, um die Tabellenblätter im Browser zu öffnen.');
  const inputRef = useRef<HTMLInputElement>(null);

  const sheet = book && sheetName ? book.Sheets[sheetName] : null;
  const range = sheet?.['!ref'] ? XLSX.utils.decode_range(sheet['!ref'] as string) : { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
  const rowCount = range.e.r + 1;
  const colCount = range.e.c + 1;
  const colNames = useMemo(() => Array.from({ length: Math.min(colCount, 40) }, (_, c) => XLSX.utils.encode_col(c)), [colCount]);

  const loadFile = async (file?: File) => {
    if (!file) return;
    try {
      const data = await file.arrayBuffer();
      const parsed = XLSX.read(data, { type: 'array', cellFormula: true, cellStyles: true, cellDates: true });
      if (!parsed.SheetNames.length) throw new Error('Keine Tabellenblätter gefunden.');
      setBook(parsed);
      setFileName(file.name);
      setSheetName(parsed.SheetNames[0]);
      setSelected(null);
      setEditValue('');
      setMessage(`„${file.name}“ wurde lokal geöffnet. Die Datei wird nicht auf einen Server hochgeladen.`);
    } catch (error) {
      setMessage(`Die Excel-Datei konnte nicht geöffnet werden: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}`);
    }
  };

  const chooseCell = (row: number, col: number) => {
    if (!sheet) return;
    const address = XLSX.utils.encode_cell({ r: row, c: col });
    const cell = sheet[address] as XLSX.CellObject | undefined;
    setSelected({ sheet: sheetName, row, col });
    setEditValue(cell?.f ? `=${cell.f}` : cell?.v == null ? '' : String(cell.v));
  };

  const applyEdit = () => {
    if (!book || !selected || selected.sheet !== sheetName) return;
    const ws = book.Sheets[sheetName];
    const address = XLSX.utils.encode_cell({ r: selected.row, c: selected.col });
    if (editValue === '') {
      delete ws[address];
    } else if (editValue.startsWith('=')) {
      ws[address] = { t: 'n', f: editValue.slice(1) };
    } else if (editValue.trim() !== '' && Number.isFinite(Number(editValue.replace(',', '.')))) {
      ws[address] = { t: 'n', v: Number(editValue.replace(',', '.')) };
    } else {
      ws[address] = { t: 's', v: editValue };
    }
    const oldRange = ws['!ref'] ? XLSX.utils.decode_range(ws['!ref'] as string) : { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
    oldRange.e.r = Math.max(oldRange.e.r, selected.row);
    oldRange.e.c = Math.max(oldRange.e.c, selected.col);
    ws['!ref'] = XLSX.utils.encode_range(oldRange);
    setBook({ ...book, Sheets: { ...book.Sheets, [sheetName]: ws } });
    setMessage(`Zelle ${address} wurde geändert. Bitte beachte: Formeln werden beim Bearbeiten nicht wie in Excel neu berechnet.`);
  };

  const exportFile = () => {
    if (!book) return;
    XLSX.writeFile(book, `${fileName.replace(/\.(xlsx|xls|xlsm)$/i, '') || 'baustellen-kalkulation'}-bearbeitet.xlsx`);
  };

  const formatCell = (cell: XLSX.CellObject | undefined) => {
    if (!cell) return '';
    if (cell.w != null) return cell.w;
    if (cell.v instanceof Date) return cell.v.toLocaleDateString('de-DE');
    return cell.v == null ? (cell.f ? `=${cell.f}` : '') : String(cell.v);
  };

  return (
    <div className="p-4 md:p-8 max-w-[1600px] mx-auto w-full space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <button onClick={onBack} className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-500 hover:text-[#8e2f2b] mb-3">
            <ArrowLeft className="w-3.5 h-3.5" /> Zurück zur Nachkalkulation
          </button>
          <p className="text-[11px] font-bold tracking-wider text-[#8e2f2b] uppercase">Excel-Werkzeug</p>
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-stone-900 mt-1">Baustellen-Nachkalkulation</h1>
          <p className="text-sm text-stone-500 mt-1">Excel-Datei öffnen, Tabellenblätter ansehen, Zellen bearbeiten und wieder exportieren.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <input ref={inputRef} type="file" accept=".xlsx,.xls,.xlsm,.xlsb,.ods" className="hidden" onChange={e => { loadFile(e.target.files?.[0]); e.currentTarget.value = ''; }} />
          <button onClick={() => inputRef.current?.click()} className="inline-flex items-center gap-2 rounded-xl bg-[#8e2f2b] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#68201f]">
            <Upload className="w-4 h-4" /> Excel-Datei öffnen
          </button>
          <button onClick={exportFile} disabled={!book} className="inline-flex items-center gap-2 rounded-xl border border-stone-200 bg-white px-4 py-2.5 text-xs font-bold text-stone-700 hover:bg-stone-50 disabled:opacity-40">
            <Download className="w-4 h-4" /> Als Excel exportieren
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {[['Auftraggeber','Auftraggeber'],['Bauvorhaben','Bauvorhaben'],['Bauleiter','Bauleiter'],['Kostenstelle','Kostenstelle']].map(([label, placeholder]) =>
          <label key={label} className="block rounded-xl border border-stone-200 bg-white p-3">
            <span className="block text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-1.5">{label}</span>
            <input placeholder={placeholder} className="w-full text-sm outline-none placeholder:text-stone-300" />
          </label>
        )}
      </div>

      <section className="overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-100 px-4 py-4">
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-[#f7eae9] p-2 text-[#8e2f2b]"><FileSpreadsheet className="w-4 h-4" /></div>
            <div><h2 className="text-sm font-extrabold text-stone-900">Kalkulationstabelle</h2><p className="text-[11px] text-stone-500">{book ? `${fileName} · ${book.SheetNames.length} Tabellenblatt/-blätter` : 'Noch keine Datei geladen'}</p></div>
          </div>
          {book && <select value={sheetName} onChange={e => { setSheetName(e.target.value); setSelected(null); setEditValue(''); }} className="max-w-full rounded-lg border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-stone-700">{book.SheetNames.map(n => <option key={n} value={n}>{n}</option>)}</select>}
        </div>
        <div className="flex items-start gap-2 border-b border-stone-100 bg-stone-50 px-4 py-3 text-xs leading-relaxed text-stone-600">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#8e2f2b]" /> {message}
        </div>
        {book && sheet && (
          <div className="flex gap-2 border-b border-stone-100 p-3">
            <span className="flex items-center px-2 text-xs font-serif italic font-bold text-stone-400">fx</span>
            <input value={editValue} onChange={e => setEditValue(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') applyEdit(); }} disabled={!selected} placeholder="Zelle auswählen, um Wert oder Formel zu bearbeiten" className="min-w-0 flex-1 rounded-lg border border-stone-200 px-3 py-2 text-xs font-mono outline-[#8e2f2b] disabled:bg-stone-50" />
            <button onClick={applyEdit} disabled={!selected} className="rounded-lg bg-stone-900 px-3 py-2 text-xs font-bold text-white disabled:opacity-40"><Check className="inline h-3.5 w-3.5 mr-1" />Übernehmen</button>
          </div>
        )}
        <div className="max-h-[65vh] overflow-auto">
          {!book || !sheet ? (
            <div className="flex flex-col items-center justify-center px-5 py-16 text-center">
              <FileSpreadsheet className="mb-3 h-10 w-10 text-stone-300" />
              <p className="text-sm font-bold text-stone-700">Deine Excel-Datei hier öffnen</p>
              <p className="mt-1 max-w-md text-xs leading-relaxed text-stone-500">Die Datei bleibt in deinem Browser. Alle Tabellenblätter werden zur Auswahl angeboten.</p>
              <button onClick={() => inputRef.current?.click()} className="mt-4 rounded-xl border border-stone-200 px-4 py-2 text-xs font-bold text-stone-700 hover:bg-stone-50">Datei auswählen</button>
            </div>
          ) : (
            <table className="border-collapse text-left text-xs">
              <thead className="sticky top-0 z-10 bg-stone-100"><tr><th className="sticky left-0 z-20 min-w-12 border-b border-r border-stone-200 bg-stone-100 px-3 py-2 text-right text-stone-500">#</th>{colNames.map(n => <th key={n} className="min-w-28 whitespace-nowrap border-b border-r border-stone-200 px-3 py-2 font-bold text-stone-600">{n}</th>)}</tr></thead>
              <tbody>{Array.from({ length: Math.min(rowCount, 500) }, (_, r) => <tr key={r} className="hover:bg-stone-50">
                <th className="sticky left-0 z-[1] border-b border-r border-stone-200 bg-stone-50 px-3 py-1.5 text-right font-medium text-stone-400">{r + 1}</th>
                {Array.from({ length: Math.min(colCount, 40) }, (_, c) => {
                  const addr = XLSX.utils.encode_cell({ r, c });
                  const cell = sheet[addr] as XLSX.CellObject | undefined;
                  const active = selected?.sheet === sheetName && selected.row === r && selected.col === c;
                  return <td key={c} onClick={() => chooseCell(r, c)} title={cell?.f ? `Formel: =${cell.f}` : undefined} className={`max-w-[260px] min-w-28 cursor-cell truncate border-b border-r border-stone-100 px-3 py-1.5 ${cell?.f ? 'text-emerald-800' : 'text-stone-700'} ${active ? 'bg-emerald-50 outline outline-2 -outline-offset-2 outline-emerald-600' : ''}`}>{formatCell(cell)}</td>;
                })}
              </tr>)}</tbody>
            </table>
          )}
        </div>
        {book && <div className="flex flex-wrap justify-between gap-2 border-t border-stone-100 px-4 py-3 text-[10px] text-stone-400"><span>{sheetName}: {rowCount} Zeilen × {colCount} Spalten {rowCount > 500 ? '· Vorschau auf 500 Zeilen begrenzt' : ''}</span><span>Formeln bleiben beim Export erhalten; eine vollständige Excel-Neuberechnung wird hier nicht garantiert.</span></div>}
      </section>
    </div>
  );
};
